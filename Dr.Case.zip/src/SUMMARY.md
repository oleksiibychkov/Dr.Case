# Зміст

[Вступ](./README.md)

# Технічна документація

- [Частина І: Роль Multilabel NN](./01_multilabel_nn_role.md)
- [Частина ІІ: Алгоритм підготовки системи](./02_system_preparation.md)
- [Частина IV: Формальні доведення гарантій](./03_formal_proofs.md)
- [Частина V: Навчання SOM + Multilabel NN](./04_training_som_nn.md)
